<?php
// generate password hash from here
echo password_hash('peperojas12', PASSWORD_DEFAULT);
